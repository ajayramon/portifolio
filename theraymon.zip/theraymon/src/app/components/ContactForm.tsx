"use client";

import { useState } from "react";

type Status = "idle" | "sending" | "sent" | "error";

export default function ContactForm() {
  const [status, setStatus] = useState<Status>("idle");
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setStatus("sending");
    setError(null);

    const form = e.currentTarget;
    const data = {
      name: (form.elements.namedItem("name") as HTMLInputElement).value,
      email: (form.elements.namedItem("email") as HTMLInputElement).value,
      project: (form.elements.namedItem("project") as HTMLTextAreaElement).value,
    };

    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) throw new Error("Request failed");

      setStatus("sent");
      form.reset();
    } catch {
      setStatus("error");
      setError("Something went wrong. Please try again or email us directly.");
    }
  }

  if (status === "sent") {
    return (
      <div className="rounded-xl border border-line-strong bg-ink-raised px-8 py-10 text-center">
        <p className="font-mono text-sm text-wire mb-2">✓ Brief received</p>
        <p className="text-fg-dim text-sm">
          We&apos;ll review it and get back to you within 48 hours.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="grid gap-4 text-left">
      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <label className="block font-mono text-xs uppercase tracking-wider text-fg-faint mb-2">
            Name
          </label>
          <input
            name="name"
            type="text"
            required
            className="w-full rounded-md border border-line-strong bg-ink px-4 py-3 text-sm text-fg outline-none focus:border-signal transition-colors"
            placeholder="Your name"
          />
        </div>
        <div>
          <label className="block font-mono text-xs uppercase tracking-wider text-fg-faint mb-2">
            Email
          </label>
          <input
            name="email"
            type="email"
            required
            className="w-full rounded-md border border-line-strong bg-ink px-4 py-3 text-sm text-fg outline-none focus:border-signal transition-colors"
            placeholder="you@company.com"
          />
        </div>
      </div>
      <div>
        <label className="block font-mono text-xs uppercase tracking-wider text-fg-faint mb-2">
          Project brief
        </label>
        <textarea
          name="project"
          required
          rows={4}
          className="w-full rounded-md border border-line-strong bg-ink px-4 py-3 text-sm text-fg outline-none focus:border-signal transition-colors resize-none"
          placeholder="What are you building?"
        />
      </div>

      {error && <p className="text-sm text-red-400 font-mono">{error}</p>}

      <button
        type="submit"
        disabled={status === "sending"}
        className="font-mono text-sm tracking-wide bg-signal text-[#14110A] font-medium rounded-md px-6 py-3.5 transition-transform hover:-translate-y-0.5 disabled:opacity-60 disabled:translate-y-0 justify-self-start"
      >
        {status === "sending" ? "Sending…" : "Send brief →"}
      </button>
    </form>
  );
}
