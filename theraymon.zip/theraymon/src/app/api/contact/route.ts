import { NextRequest, NextResponse } from "next/server";

type ContactPayload = {
  name?: string;
  email?: string;
  project?: string;
};

export async function POST(req: NextRequest) {
  let body: ContactPayload;

  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const { name, email, project } = body;

  if (!name || !email || !project) {
    return NextResponse.json(
      { error: "Name, email, and project brief are required." },
      { status: 400 }
    );
  }

  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(email)) {
    return NextResponse.json({ error: "Invalid email address." }, { status: 400 });
  }

  // In production, wire this up to an email provider (Resend, Postmark, SendGrid)
  // or write the lead to a database / CRM. Logging for now so the endpoint is
  // fully functional out of the box.
  console.log("New project brief:", { name, email, project });

  return NextResponse.json({ ok: true });
}
